package com.example.core.data

class AppExecutors {

}