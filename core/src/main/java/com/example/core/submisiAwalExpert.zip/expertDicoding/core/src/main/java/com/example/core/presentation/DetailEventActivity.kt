package com.example.core.presentation



import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Html
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.core.R
import com.example.core.data.SettingPreferences
import com.example.core.data.AppExecutors
import com.example.core.data.NewsDao
import com.example.core.data.NewsDatabase
import com.example.core.data.dataStore
import com.example.core.databinding.ActivityDetailEventBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DetailEventActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailEventBinding
    private lateinit var newsDao: NewsDao
    private lateinit var appExecutors: AppExecutors

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        enableEdgeToEdge()

        binding = ActivityDetailEventBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = NewsDatabase.getInstance(applicationContext)
        newsDao = db.newsDao()
        appExecutors = AppExecutors()

        val person = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_PERSON, com.example.core.data.NewsEntity::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_PERSON)
        }

        if (person != null) {
            updateFavoriteIcon(person.isBookmarked)

            binding.tvItemName.text = person.title
            binding.tvItemDescription.text = person.summary

            Glide.with(this)
                .load(person.urlToImage)
                .into(binding.imgItemPhoto)

            val penyelenggaraText = StringBuilder("Penyelenggara: ").append(person.penyelenggaraAcara)
            val waktuText = StringBuilder("Waktu: ").append(person.waktu)
            val quotaText = StringBuilder("Kuota: ").append(person.quota - person.registrasi)
            val linkText = StringBuilder("Link: ").append(person.link)

            binding.tvPenyelenggara.text = penyelenggaraText.toString()
            binding.tvWaktu.text = waktuText.toString()
            binding.tvQuota.text = quotaText.toString()
            binding.tvLink.text = linkText.toString()

            binding.tvDeskripsi.text = Html.fromHtml(person.desckripsi, Html.FROM_HTML_MODE_LEGACY)

            binding.btnRegister.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW)
                intent.data = Uri.parse(person.link)
                startActivity(intent)
            }

            binding.backIcon.setOnClickListener {
                finish()
            }

            binding.ivFavorite.setOnClickListener {
                person.isBookmarked = !person.isBookmarked
                updateFavoriteIcon(person.isBookmarked)
                setBookmarkedNews(person, person.isBookmarked)
            }
        }

        val pref = SettingPreferences.getInstance(application.dataStore)
        val mainViewModel = ViewModelProvider(
            this,
            DataViewModelFactory(pref)
        )[MainViewModel::class.java]

        mainViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                binding.backIcon.setImageDrawable(ContextCompat.getDrawable(binding.backIcon.context,
                    R.drawable.baseline_keyboard_backspace_24_white
                ))
            } else {
                binding.backIcon.setImageDrawable(ContextCompat.getDrawable(binding.backIcon.context,
                    R.drawable.baseline_keyboard_backspace_24
                ))
            }
        }

    }

    private fun setBookmarkedNews(news: com.example.core.data.NewsEntity, bookmarkState: Boolean) {
        lifecycleScope.launch(Dispatchers.IO) {
            news.isBookmarked = bookmarkState
            newsDao.updateNews(news)
        }
    }


    private fun updateFavoriteIcon(isBookmarked: Boolean) {
        val iconResId = if (isBookmarked) {
            R.drawable.baseline_favorite_24
        } else {
            R.drawable.baseline_favorite_border_24
        }
        binding.ivFavorite.setImageDrawable(
            ContextCompat.getDrawable(this, iconResId)
        )
    }

    companion object {
        const val EXTRA_PERSON = "extra_person"
    }
}
