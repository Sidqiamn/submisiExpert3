package com.example.core.data

import android.util.Log
import com.example.core.data.service.ApiService
import com.example.core.domain.Result
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*


class NewsRepository private constructor(
    private val apiService: ApiService,
    private val newsDao: NewsDao,
    private val appExecutors: AppExecutors
) {

    fun getHeadlineNews(): Flow<Result<List<NewsEntity>>> = flow {
        emit(Result.Loading)

        try {
            // Ambil data dari API
            val response = apiService.getActiveEvents()
            val articles = response.listEvents

            Log.d("NewsRepository", "Data API berhasil diambil: ${articles.size} artikel")

            // Map data API ke entitas database
            val newsList = articles.map { article ->
                val isBookmarked = newsDao.isNewsBookmarked(article.name)
                NewsEntity(
                    title = article.name,
                    summary = article.summary,
                    penyelenggaraAcara = article.ownerName,
                    waktu = article.beginTime,
                    quota = article.quota,
                    link = article.link,
                    desckripsi = article.description,
                    registrasi = article.registrants,
                    publishedAt = article.summary,
                    urlToImage = article.imageLogo,
                    url = article.link,
                    isBookmarked = isBookmarked
                )
            }

            // Simpan data ke database
            newsDao.deleteAll()
            newsDao.insertNews(newsList)

            // Emit data dari database
            val localData = newsDao.getNews()
            emitAll(localData.map { Result.Success(it) })
        } catch (e: Exception) {
            emit(Result.Error(e.message.toString()))
            Log.e("NewsRepository", "Gagal mengambil data dari API: ${e.message}")
        }
    }.catch { e ->
        emit(Result.Error("Error: ${e.message}"))
        Log.e("NewsRepository", "Error Flow: ${e.message}")
    }.flowOn(Dispatchers.IO)

    fun getBookmarkedNews(): Flow<List<NewsEntity>> =
        newsDao.getBookmarkedNews()
            .catch { e ->
                Log.e("NewsRepository", "Error Bookmarked Flow: ${e.message}")
            }
            .flowOn(Dispatchers.IO)

    suspend fun setBookmarkedNews(news: NewsEntity, bookmarkState: Boolean) {
        news.isBookmarked = bookmarkState
        newsDao.updateNews(news)
    }

    companion object {
        @Volatile
        private var instance: NewsRepository? = null

        fun getInstance(
            apiService: ApiService,
            newsDao: NewsDao,
            appExecutors: AppExecutors
        ): NewsRepository =
            instance ?: synchronized(this) {
                instance ?: NewsRepository(apiService, newsDao, appExecutors)
            }.also { instance = it }
    }
}
