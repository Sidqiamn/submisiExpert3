package com.example.core.data.service

import com.example.core.domain.EventResponse
import retrofit2.http.GET

interface ApiService {
    @GET("events?active=1")
  suspend  fun getActiveEvents(): EventResponse
}