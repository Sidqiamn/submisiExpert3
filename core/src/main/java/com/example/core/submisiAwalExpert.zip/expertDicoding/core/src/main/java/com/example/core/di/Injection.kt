package com.example.core.di


import com.example.core.data.NewsRepository
import com.example.core.data.NewsDatabase
import com.example.core.data.service.ApiConfig
import com.example.core.data.AppExecutors
import com.example.core.presentation.NewsViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {
    single { ApiConfig.getApiService() }

    single { NewsDatabase.getInstance(get()) }

    single { get<NewsDatabase>().newsDao() }

    single { AppExecutors() }

    single { NewsRepository.getInstance(get(), get(), get()) }
    viewModel { NewsViewModel(get()) }
}




