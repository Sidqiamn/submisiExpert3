package com.example.core.presentation
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.domain.Result
import com.example.core.data.NewsEntity
import com.example.core.data.NewsRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NewsViewModel(private val newsRepository: NewsRepository) : ViewModel() {

    private val _headlineNews = MutableStateFlow<Result<List<NewsEntity>>>(Result.Loading)
    val getHeadlineNews: StateFlow<Result<List<NewsEntity>>> = _headlineNews

    private val _bookmarkedNews = MutableStateFlow<List<NewsEntity>>(emptyList())
    val getBookmarkedNews: StateFlow<List<NewsEntity>> = _bookmarkedNews

    init {
        fetchHeadlineNews()
        fetchBookmarkedNews()
    }

    private fun fetchHeadlineNews() {
        viewModelScope.launch {
            newsRepository.getHeadlineNews()
                .catch { e -> _headlineNews.value = Result.Error(e.toString()) }
                .collect { result -> _headlineNews.value = result }
        }
    }

    private fun fetchBookmarkedNews() {
        viewModelScope.launch {
            newsRepository.getBookmarkedNews()
                .catch { _ -> _bookmarkedNews.value = emptyList() }
                .collect { newsList -> _bookmarkedNews.value = newsList }
        }
    }

    fun saveNews(news: NewsEntity) {
        viewModelScope.launch {
            newsRepository.setBookmarkedNews(news, true)
        }
    }

    fun deleteNews(news: NewsEntity) {
        viewModelScope.launch {
            newsRepository.setBookmarkedNews(news, false)
        }
    }
}
