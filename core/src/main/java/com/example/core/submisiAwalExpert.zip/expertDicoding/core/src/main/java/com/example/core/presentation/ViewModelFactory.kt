package com.example.core.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.core.data.NewsRepository
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

class ViewModelFactory : ViewModelProvider.NewInstanceFactory(), KoinComponent {
    private val newsRepository: NewsRepository by inject()

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NewsViewModel::class.java)) {
            return NewsViewModel(newsRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }
}
